# Exposé der Gruppe 4

## Gruppenvorstellung
...

## Kurzbeschreibung des Systems
...

### Welche Zielgruppe?
...

### Welche Plattform und Konnektivität?
- Windows, Linux, macOS, Android, iOS etc.
- Offline, Online, Mobile embedded ...

### Benutzeroberflächentechnologie
- z.B. HTML5, CSS3 und JavaScript via Twitter Bootstrap Framework

### Schnittstellen
- z.B. REST API

### Wie wird das System gesteuert?
- ...

### Wie interagiert der Benutzer?
- z.B. Konsolenbefehle, Benutzeroberfläche, Smartphone App etc.

### Welche Technologien sollen eingesetzt werden?
- z.B. NodeJS, Bootstrap, Angular, SQLite, Progessive Web Apps (PWA), ...
