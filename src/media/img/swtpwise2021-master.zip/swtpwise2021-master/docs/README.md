# Verzeichnis für Dokumentenaustausch

Zu diesen Dokumenten können gehören:
- Diagramme
- Entwürfe (Beschreibung als Textdatei mit Markdown)
- ...
