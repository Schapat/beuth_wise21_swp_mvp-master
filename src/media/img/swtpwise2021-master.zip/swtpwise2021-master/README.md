# swtpwise2021
Willkommen beim git Repository des Projektes "Name wird noch gesucht" (Beuth Hochschule Modul: Softwaretechnik-Projekt)

## Aufgabenstellung
- Meilstone 1 - Exposé erstellen
- ...

## Weitere Arbeitsmittel
- Beuth Cloud: https://cloud.beuth-hochschule.de/index.php/f/24768391

## Definition Verzeichnisse in gitlab
| Verzeichnisname | Kurzbeschreibung |
| ------ | ------ |
| docs | Verzeichnis für Dokumente (z.B. Entwürfe, Diagramme etc.) |
| src | Verzeichnis für den Programmcode |

## Hilfestellungen
- Wikipedia-Artikel zu Markdown: https://de.wikipedia.org/wiki/Markdown
- freies Buch zum Arbeiten mit git: https://git-scm.com/book/de/v2
